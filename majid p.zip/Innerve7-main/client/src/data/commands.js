export default [
    {
        dialog: "Name: My First Name is *"
    },
    {
        dialog: "Name: My last Name is *"
    },
    {
        dialog: "Age: I am * years old"
    },
    {
        dialog: "Origin: I want to go from * "
    },
    {
        dialog: "Destination: to *"
    },
    {
        dialog: "Travel Date: I have a ticket on * "
    },
    {
        dialog: "CheckIn date: I want to book hotel from *"
    },
    {
        dialog: "CheckOut date: Till *"
    },
    {
        dialog: "Guests: we are * people"
    },
    {
        dialog: "Phone No: My phone number is *"
    },
    {
        dialog: "Email:  My email address is *"
    },

]