import React from 'react'

function SuccessComponent() {
  return (
    <div>
        <h1 style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            height: '100vh',
            width: '100vw',
            background: '#f8f8f8'
        }}>Payment Success</h1>
    </div>
  )
}

export default SuccessComponent