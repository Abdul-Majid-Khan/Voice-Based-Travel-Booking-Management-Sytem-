client side 

4 routes 
1) /  => home page 
2) /hotels => list of hotels 
3) /hotels/id => individual hotel
4) /payment/id/price => payment gateway


all payment at 
```
https://dashboard.stripe.com/test/payments
```

1) hoteldetail.js page => line 20 
2) hotels.jsx =>line  => line 47, line 86
